//
//  AramaVC.swift
//  HemenYesek
//
//  Created by Ummugulsum Çekin on 31.05.2022.
//

import UIKit

class AramaVC: UIViewController {

    @IBOutlet weak var yemekAraSearchBar: UISearchBar!
    @IBOutlet weak var aramaTableView: UITableView!
    
    @IBOutlet weak var restoranImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

}
