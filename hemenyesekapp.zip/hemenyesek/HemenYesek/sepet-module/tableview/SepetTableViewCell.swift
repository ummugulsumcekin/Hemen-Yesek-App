//
//  SepetTableViewCell.swift
//  HemenYesek
//
//  Created by Ummugulsum Çekin on 31.05.2022.
//

import UIKit

class SepetTableViewCell: UITableViewCell {

    @IBOutlet weak var sepetHucreArkaplan: UIView!
    
    @IBOutlet weak var sepetYemekAdLabel: UILabel!
    
    @IBOutlet weak var sepetImageView: UIImageView!
    
    @IBOutlet weak var sepetAdetLabel: UILabel!
    
    @IBOutlet weak var sepetFiyatLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
