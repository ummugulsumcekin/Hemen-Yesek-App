//
//  Protocols.swift
//  HemenYesek
//
//  Created by Ummugulsum Çekin on 31.05.2022.
//
import Foundation
