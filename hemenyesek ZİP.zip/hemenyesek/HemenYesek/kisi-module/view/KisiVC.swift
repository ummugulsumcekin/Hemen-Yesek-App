//
//  KisiVC.swift
//  HemenYesek
//
//  Created by Ummugulsum Çekin on 31.05.2022.
//

import UIKit

class KisiVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
